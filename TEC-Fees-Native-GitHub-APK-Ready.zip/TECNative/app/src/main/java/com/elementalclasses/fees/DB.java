package com.elementalclasses.fees;

import android.content.*;import android.database.sqlite.*;import android.database.*;import java.util.*;

public class DB extends SQLiteOpenHelper {
 public DB(Context c){super(c,"tec_fees.db",null,1);}
 public void onCreate(SQLiteDatabase d){
  d.execSQL("CREATE TABLE batches(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,subject TEXT,timing TEXT,teacher TEXT,fee REAL)");
  d.execSQL("CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,mobile TEXT,batch_id INTEGER,total_fee REAL,admission_date TEXT,roll_no TEXT,photo TEXT)");
  d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,amount REAL,date TEXT)");
 }
 public void onUpgrade(SQLiteDatabase d,int o,int n){}
 public Cursor batches(){return getReadableDatabase().rawQuery("SELECT b.*,COUNT(s.id) students,COALESCE(SUM(s.total_fee),0) fees,COALESCE((SELECT SUM(p.amount) FROM payments p JOIN students ss ON ss.id=p.student_id WHERE ss.batch_id=b.id),0) paid FROM batches b LEFT JOIN students s ON s.batch_id=b.id GROUP BY b.id ORDER BY b.id DESC",null);}
 public Cursor students(long batch){return getReadableDatabase().rawQuery("SELECT s.*,COALESCE((SELECT SUM(amount) FROM payments p WHERE p.student_id=s.id),0) paid FROM students s WHERE s.batch_id=? ORDER BY s.roll_no+0,s.name",new String[]{String.valueOf(batch)});}
 public Cursor allStudents(){return getReadableDatabase().rawQuery("SELECT s.*,b.name batch,COALESCE((SELECT SUM(amount) FROM payments p WHERE p.student_id=s.id),0) paid FROM students s LEFT JOIN batches b ON b.id=s.batch_id ORDER BY s.name",null);}
 public double totalFees(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total_fee),0) FROM students",null);c.moveToFirst();double v=c.getDouble(0);c.close();return v;}
 public double totalPaid(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments",null);c.moveToFirst();double v=c.getDouble(0);c.close();return v;}
 public long addBatch(String n,String s,String t,String te,double f){ContentValues v=new ContentValues();v.put("name",n);v.put("subject",s);v.put("timing",t);v.put("teacher",te);v.put("fee",f);return getWritableDatabase().insert("batches",null,v);}
 public long addStudent(String n,String m,long b,double fee,String date,String roll){ContentValues v=new ContentValues();v.put("name",n);v.put("mobile",m);v.put("batch_id",b);v.put("total_fee",fee);v.put("admission_date",date);v.put("roll_no",roll);return getWritableDatabase().insert("students",null,v);}
 public long pay(long sid,double amt,String date){ContentValues v=new ContentValues();v.put("student_id",sid);v.put("amount",amt);v.put("date",date);return getWritableDatabase().insert("payments",null,v);}
 public void deleteBatch(long id){getWritableDatabase().delete("students","batch_id=?",new String[]{""+id});getWritableDatabase().delete("batches","id=?",new String[]{""+id});}
}
